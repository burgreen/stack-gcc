#!/bin/bash

#set -x
#set -e

#--------------------------------------------
# purpose: install a reliable gcc
#
# author: greg.burgreen@msstate.edu
#         Mississippi State Univ, July 2018
#--------------------------------------------

if [ -z "$1" ]; then 
  echo
  echo usage: $0 \<compiler\>
  echo
  echo where \<compiler\> is a compiler known to
  echo successfully install a Spack package.
  echo
  echo For example, $0 gcc@5.3.0
  exit
fi

echo -----------------------------------------------
echo scripts/install-pkg-gcc.sh $1
echo -----------------------------------------------

#--------------------------------------------
# 0. gcc version in archive to be installed
#--------------------------------------------

ver=7.3.0

#--------------------------------------------
# 1. prelims
#--------------------------------------------

compiler=$1

source ./1-setup-spack.sh

#--------------------------------------------
# 2. unarchive tarballs
#--------------------------------------------

#source ./3-names.sh
#tar xfv $sys_sources
#tar xfv $sys_packages

echo -----------------------------------------------
echo scripts/install-pkg-gcc.sh $1
echo -----------------------------------------------

#--------------------------------------------
# 3. install compiler and binutils
#--------------------------------------------

#source ./scripts/install-prep.sh

spack install gcc@$ver %$compiler

#--------------------------------------------
# 4. write file: compilers.yaml
#--------------------------------------------

gcc_dir=$(spack location -i gcc@$ver)

spack_version=new

if [ $spack_version == old ]; then
  IFS='-' read -ra arch <<< "$(spack arch)"
  os=${arch[1]}
  target=${arch[2]}
else
  os=$(spack arch -o)
  target=$(spack arch -t)
fi

cat > ./etc/spack/compilers.yaml << EOF
compilers:
- compiler:
    environment: {}
    extra_rpaths: []
    flags: {}
    modules: []
    operating_system: $os
    paths:
      cc: $gcc_dir/bin/gcc
      cxx: $gcc_dir/bin/g++
      f77: $gcc_dir/bin/gfortran
      fc: $gcc_dir/bin/gfortran
    spec: spack-gcc@7.3.0
    target: $target
EOF

#--------------------------------------------
# 3. modify file: packages.yaml
#--------------------------------------------

# need this??

#cat >> etc/spack/packages.yaml << EOF
#    compiler: [spack-gcc]
#EOF

#--------------------------------------------
# 5. append to file: 2-setup-compiler.sh
#--------------------------------------------

cat >> 2-setup-compiler.sh << EOF
#------------------------------------
# added compiler: spack-gcc
#------------------------------------

spack_compiler=spack-gcc

$(spack module tcl loads gcc | grep load)

unset  F90
export FC=$gcc_dir/bin/gfortran
EOF

#--------------------------------------------
# 6. finales
#--------------------------------------------

echo -----------------------------------------------
echo scripts/install-pkg-gcc.sh done
echo -----------------------------------------------

#set +e
#set +x
