#!/bin/bash

#set -x
set -e

#--------------------------------------------
# purpose: install a reliable gcc & binutils, & curl
#          install proteus stack
#
# author: greg.burgreen@msstate.edu
#         Mississippi State Univ, July 2018
#--------------------------------------------

#if [ -z "$1" ]; then 
#  echo
#  echo usage: $0 \<compiler\>
#  echo
#  echo where \<compiler\> is a compiler known to 
#  echo successfully install a Spack package.
#  echo
#  echo For example, $0 gcc@5.3.0
#  exit
#fi

echo -----------------------------------------------
echo scripts/install-compiler-gcc.sh $1
echo -----------------------------------------------

#--------------------------------------------
# 1. prelims
#--------------------------------------------

if [ ! -f ./1-setup-spack.sh ]; then
   echo Error: Missing 1-setup-spack.sh
   echo Follow instructions at github.com/burgreen/stack-spack
   exit
fi

if [ ! -f ./2-setup-compiler.sh ]; then
   echo Error: Missing 2-setup-compiler.sh
   echo Did you ./scripts/compiler.sh finalize \<compiler\>\?
   exit
fi

source ./1-setup-spack.sh
source ./2-setup-compiler.sh

compiler=$spack_compiler

echo Using compiler: $spack_compiler

#--------------------------------------------
# 2. install system pkgs: gcc, binutils, curl
#--------------------------------------------

./scripts/install-pkg-gcc.sh $compiler
./scripts/install-pkg-binutils.sh $compiler

spack load binutils

#--------------------------------------------
# 3. install system pkgs: curl using spack-gcc
#--------------------------------------------

./scripts/install-pkg-curl.sh spack-gcc

#--------------------------------------------
# 5. finales
#--------------------------------------------

echo -----------------------------------------------
echo scripts/install-compiler-gcc.sh done
echo -----------------------------------------------

#set +e
#set +x
