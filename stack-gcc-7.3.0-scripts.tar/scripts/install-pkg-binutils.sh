#!/bin/bash

#set -x
set -e

#--------------------------------------------
# purpose: install a reliable binutils
#
# author: greg.burgreen@msstate.edu
#         Mississippi State Univ, July 2018
#--------------------------------------------

if [ -z "$1" ]; then 
  echo
  echo usage: $0 \<compiler\>
  echo
  echo where \<compiler\> is a compiler known to
  echo successfully install a Spack package.
  echo
  echo For example, $0 gcc@5.3.0
  exit
fi

ver=x.x.x

echo -----------------------------------------------
echo scripts/install-pkg-binutils.sh $1
echo -----------------------------------------------

#--------------------------------------------
# 1. prelims
#--------------------------------------------

compiler=$1

source ./1-setup-spack.sh

#--------------------------------------------
# 2. unarchive tarballs
#--------------------------------------------

#source ./3-names.sh
#tar xfv $sys_sources
#tar xfv $sys_packages

echo -----------------------------------------------
echo scripts/install-pkg-binutils.sh $compiler
echo -----------------------------------------------

#--------------------------------------------
# 3. install compiler and binutils
#--------------------------------------------

#source ./scripts/install-prep.sh

spack install binutils %$compiler

#--------------------------------------------
# 5. append to file: 1-setup-compiler.sh
#--------------------------------------------

cat >> 2-setup-compiler.sh << EOF

$(spack module tcl loads binutils | grep load)
EOF

#--------------------------------------------
# 6. finales
#--------------------------------------------

echo -----------------------------------------------
echo scripts/install-pkg-binutils.sh done
echo -----------------------------------------------

#set +e
#set +x
